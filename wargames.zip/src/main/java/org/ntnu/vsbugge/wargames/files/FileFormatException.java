package org.ntnu.vsbugge.wargames.files;

import java.io.IOException;

public class FileFormatException extends IOException {
    public FileFormatException(String message) {
        super(message);
    }
}
